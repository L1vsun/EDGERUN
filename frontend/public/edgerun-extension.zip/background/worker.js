// The only place that talks to the network.
//
// Content scripts never fetch anything themselves - they ask for a verdict and get one back,
// from cache where possible. That is what keeps a timeline with forty tickers on screen from
// turning into forty requests: identical addresses collapse into one in-flight promise, the
// whole batch resolves in a single JSON-RPC round trip, and everything is cached by address.
//
// MV3 kills this worker after ~30 s idle, so nothing important lives in a variable: the
// registry, the verdict cache, the watchlist and the spend budget are all in storage.

import { getBlocklist } from "../lib/blocklist.js";
import { remaining } from "../lib/budget.js";
import { ALL as ALL_CHAINS } from "../lib/chains.js";
import { whereItLives } from "../lib/crosschain.js";
import { getList, listCheck } from "../lib/lists.js";
import { isSolanaAddress } from "../lib/base58.js";
import * as solana from "../lib/solana.js";
import { deployerTrail, trailChecks } from "../lib/deployer.js";
import { exitSweep } from "../lib/exit.js";
import * as graph from "../lib/graph.js";
import * as ledger from "../lib/ledger.js";
import { pruneMemory, rememberAndRecall } from "../lib/memory.js";
import { parseClaims, validateClaim } from "../lib/claim.js";
import { runClaim } from "../lib/verify.js";
import { readMarket } from "../lib/market.js";
import { readCandles } from "../lib/candles.js";
import { getRegistry } from "../lib/registry.js";
import { isAddress, lookupTicker, rankCandidates, resolveTicker, scan, scanMany } from "../lib/verdict.js";

const TTL = { identity: 15 * 60 * 1000, full: 5 * 60 * 1000 };
const TICKER_TTL = 6 * 60 * 60 * 1000; // which contracts claim a ticker barely changes
const cacheKey = (address, level) => `v:${level}:${address.toLowerCase()}`;
const inflight = new Map();

async function cacheGet(address, level) {
  try {
    const key = cacheKey(address, level);
    const got = await chrome.storage.local.get(key);
    const hit = got[key];
    if (hit && Date.now() - hit.scannedAt < TTL[level]) return hit;
  } catch {
    /* storage blocked: just re-scan */
  }
  return null;
}

const cachePut = (result) =>
  chrome.storage.local.set({ [cacheKey(result.address, result.level)]: result }).catch(() => {});

/** A full verdict outranks an identity one for display, so prefer it when it is still warm. */
async function bestCached(address) {
  return (await cacheGet(address, "full")) || (await cacheGet(address, "identity"));
}

async function getVerdict(address, level = "identity", { fresh = false } = {}) {
  if (!isAddress(address)) throw new Error("that is not a contract address");
  const addr = address.toLowerCase();
  if (!fresh) {
    const cached = level === "identity" ? await bestCached(addr) : await cacheGet(addr, level);
    if (cached) return { ...cached, cached: true };
  }
  const key = `${level}:${addr}`;
  if (inflight.has(key)) return inflight.get(key);
  const p = scan(addr, { level })
    .then(async (r) => {
      // recorded once, on the fresh scan - a cached read must not inflate "seen 9 times"
      const notes = await rememberAndRecall(r);
      const out = notes.length ? { ...r, checks: [...r.checks, ...notes] } : r;
      cachePut(out);
      return out;
    })
    .finally(() => inflight.delete(key));
  inflight.set(key, p);
  return p;
}

async function getVerdicts(addresses) {
  const wanted = [...new Set((addresses || []).filter(isAddress).map((a) => a.toLowerCase()))];
  const out = {};
  const missing = [];
  for (const addr of wanted) {
    const cached = await bestCached(addr);
    if (cached) out[addr] = { ...cached, cached: true };
    else missing.push(addr);
  }
  if (missing.length) {
    const fresh = await scanMany(missing);
    for (const [addr, r] of Object.entries(fresh)) {
      const notes = await rememberAndRecall(r);
      const withNotes = notes.length ? { ...r, checks: [...r.checks, ...notes] } : r;
      out[addr] = withNotes;
      cachePut(withNotes);
    }
  }
  return out;
}

// The deployer trail is slow and expensive, so it is asked for explicitly and cached for an
// hour - a wallet's launch history does not change minute to minute.
const trailCache = new Map();
async function getTrail(address) {
  const addr = String(address).toLowerCase();
  const hit = trailCache.get(addr);
  if (hit && Date.now() - hit.at < 60 * 60 * 1000) return hit.data;
  const trail = await deployerTrail(addr);
  const data = { trail, checks: trailChecks(trail) };
  trailCache.set(addr, { at: Date.now(), data });
  return data;
}

// The size sweep is one batched POST but still a real round trip, and the answer only moves
// when the contract's limits do. Ten minutes is short enough to catch a limit being switched
// on mid-session and long enough that reopening a row is free.
const exitCache = new Map();
async function getExitSweep(address) {
  const addr = String(address).toLowerCase();
  const hit = exitCache.get(addr);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.data;
  const data = await exitSweep(addr);
  exitCache.set(addr, { at: Date.now(), data });
  return data;
}

// ---- Solana ----
//
// Same cache shape as the EVM side and a separate key space, because a base58 mint and a hex
// address can never collide but the two scans answer different questions and have different
// costs.
const SOL_TTL = 10 * 60 * 1000;
const solCache = new Map();

async function getMint(mint, { fresh = false } = {}) {
  const hit = solCache.get(mint);
  if (!fresh && hit && Date.now() - hit.at < SOL_TTL) return hit.data;
  const data = await solana.scanMint(mint);
  solCache.set(mint, { at: Date.now(), data });
  return data;
}

/**
 * Resolve base58 candidates found in page text.
 *
 * The content script cannot decode base58, so what arrives here is "32 to 44 characters that
 * could be a key" - most of which are not. Validation drops the junk, and anything that is a
 * real account but not a MINT is dropped too rather than badged: a wallet address in a post
 * is not a token, and putting "this is not a mint" under every post that quotes one is the
 * bare-ticker noise problem in a new alphabet.
 */
async function resolveMints(candidates, { fresh = false } = {}) {
  const wanted = [...new Set(candidates || [])].filter(isSolanaAddress).slice(0, 4);
  const out = [];
  for (const mint of wanted) {
    try {
      const r = await getMint(mint, { fresh });
      if (r.verdict === "UNRESOLVED" && !r.symbol) continue; // not a mint, or unreadable
      out.push(r);
    } catch {
      /* one bad mint must not sink the batch */
    }
  }
  return out;
}

// Dexscreener puts the *pair* in the URL, not the token - and on this chain some of those
// are Uniswap v4 pool ids (32 bytes), not addresses. Resolving pair -> baseToken is the
// worker's job because it owns the network and the cache.
async function resolvePair(pairId) {
  const key = `pair:${pairId.toLowerCase()}`;
  try {
    const got = await chrome.storage.local.get(key);
    if (got[key]) return got[key];
  } catch {}
  const res = await fetch(`https://api.dexscreener.com/latest/dex/pairs/robinhood/${pairId}`);
  if (!res.ok) throw new Error(`dexscreener HTTP ${res.status}`);
  const pair = (await res.json())?.pairs?.[0];
  if (!pair) throw new Error("no such pair on this chain");
  const info = {
    baseToken: pair.baseToken?.address?.toLowerCase() || null,
    baseSymbol: pair.baseToken?.symbol || null,
    quoteSymbol: pair.quoteToken?.symbol || null,
    dex: pair.dexId || null,
    labels: pair.labels || [],
  };
  chrome.storage.local.set({ [key]: info }).catch(() => {});
  return info;
}

// ---- watchlist: local only, never synced anywhere ----

async function watchList() {
  try {
    const got = await chrome.storage.local.get("watch");
    return got.watch || [];
  } catch {
    return [];
  }
}

async function watchToggle(address) {
  const addr = String(address).toLowerCase();
  const list = await watchList();
  const next = list.some((w) => w.address === addr)
    ? list.filter((w) => w.address !== addr)
    : [...list, { address: addr, at: Date.now() }];
  await chrome.storage.local.set({ watch: next });
  return next;
}

/**
 * Fold fresh verdicts into the watchlist and report what moved.
 *
 * This is the whole point of watching something. A list that only ever shows the current
 * verdict makes you remember what it said last time, which nobody does - so the verdict at
 * each sighting is stored and the change is what gets surfaced. Ownership un-renounced, a
 * blacklist switched on after launch, a PASS that quietly became a FAIL: all of it is a
 * comparison against a number we kept, not something the chain will tell you.
 */
async function watchSync(verdicts) {
  const list = await watchList();
  const byAddress = new Map(list.map((w) => [w.address, w]));
  const changes = [];
  const now = Date.now();
  for (const [address, verdict] of Object.entries(verdicts || {})) {
    const w = byAddress.get(address);
    if (!w) continue;
    if (w.verdict && w.verdict !== verdict) changes.push({ address, from: w.verdict, to: verdict, since: w.checkedAt || w.at });
    byAddress.set(address, { ...w, verdict, checkedAt: now });
  }
  await chrome.storage.local.set({ watch: [...byAddress.values()] });
  return changes;
}

// Every handler gets the sender, because a verdict is only half the story - which tab asked
// is what turns a stream of one-off checks into a readable session.
const HANDLERS = {
  // A check asked for by the side panel has no sender.tab - it is an extension page - so the
  // source page is passed explicitly. Without this, anything typed into the panel would be
  // recorded with no idea where it came from.
  verdict: async (m, sender) => {
    const r = await getVerdict(m.address, m.level || "identity", { fresh: m.fresh });
    await ledger.record(sender?.tab?.url ?? m.url, r);
    return r;
  },
  verdicts: async (m, sender) => {
    const out = await getVerdicts(m.addresses);
    await ledger.recordMany(sender?.tab?.url ?? m.url, Object.values(out));
    return out;
  },
  ticker: (m) => resolveTicker(m.ticker),
  tickers: async (m) => {
    // An official ticker costs nothing (the registry is already local). Anything else needs
    // one explorer search, so it is cached hard - a ticker's contract set barely moves, and
    // a timeline full of $PEPE must not spend a search per post.
    const out = {};
    for (const t of [...new Set(m.tickers || [])].slice(0, 12)) {
      const key = `tk:${t.toUpperCase()}`;
      try {
        const got = await chrome.storage.local.get(key);
        if (got[key] && Date.now() - got[key].at < TICKER_TTL) {
          if (got[key].hit) out[t] = got[key].hit;
          continue;
        }
      } catch {}
      const hit = await lookupTicker(t);
      chrome.storage.local.set({ [key]: { at: Date.now(), hit } }).catch(() => {});
      if (hit) out[t] = hit;
    }
    return out;
  },
  pair: (m) => resolvePair(m.pairId),
  deployer: (m) => getTrail(m.address),
  exit: (m) => getExitSweep(m.address),
  rank: (m) => rankCandidates(m.addresses),
  blocklist: () => getBlocklist().then((b) => ({ count: b.count, updated: b.updated, source: b.source })),
  registry: () => getRegistry().then((r) => ({ loaded: r.loaded, count: r.count || 0, error: r.error, fetchedAt: r.fetchedAt })),
  budget: async () => ({ blockscout: await remaining("blockscout"), rpc: await remaining("rpc") }),
  "watch:list": () => watchList(),
  "watch:toggle": (m) => watchToggle(m.address),
  "watch:sync": (m) => watchSync(m.verdicts),

  /**
   * Where else this address exists, and what a curated list says about it there.
   *
   * On demand only, never on the feed. It is one request per chain, and a timeline batch
   * that fanned out across five chains per post would spend a minute's budget in a scroll -
   * the same reason the deployer trail and the exit sweep are buttons rather than automatic.
   */
  crosschain: async (m) => {
    const found = await whereItLives(m.address, { fresh: m.fresh });
    const list = await getList();
    const chains = found.chains.map((row) =>
      row.present === true
        ? { ...row, list: listCheck(list, { chainId: row.id, address: found.address, symbol: row.symbol }) }
        : row,
    );
    return { ...found, chains, listLoaded: Boolean(list.loaded) };
  },

  // Solana. A separate provider, not a chain row - see lib/solana.js.
  mint: (m) => getMint(m.address, { fresh: m.fresh }),
  mints: async (m, sender) => {
    const out = await resolveMints(m.candidates, { fresh: m.fresh });
    await ledger.recordMany(sender?.tab?.url ?? m.url, out);
    return out;
  },

  chains: () => ALL_CHAINS.map(({ key, id, name, authority, explorer }) => ({ key, id, name, authority, explorer: Boolean(explorer) })),

  // ---- the account graph: who put that contract in front of you ----
  //
  // Written by the X surface, read by the panel. It lives in the worker for the same reason
  // the ledger does: a content script on x.com must not be able to read back the record of
  // every account you have ever scrolled past.
  "graph:record": (m) => graph.recordSightings(m.sightings),
  "graph:caller": (m) => graph.callerRecord(m.handle),
  "graph:callers": (m) => graph.callerRecords(m.handles),
  "graph:token": (m) => graph.tokenCallers(m.address),
  "graph:tokens": (m) => graph.tokenCallersMany(m.addresses),
  "graph:top": (m) => graph.topCallers(m.limit),
  "graph:stats": () => graph.graphStats(),
  "graph:pause": (m) => graph.setPaused(m.paused),
  "graph:wipe": () => graph.wipeGraph(),

  // ---- the sidebar ----
  "ledger:get": () => ledger.read(),
  "ledger:clear": () => ledger.clear().then(() => ({ cleared: true })),

  /**
   * Open the side panel beside the tab that asked.
   *
   * chrome.sidePanel.open() needs a user gesture, and the gesture here happened in a content
   * script (a click on the badge) rather than in an extension page. Whether that survives the
   * hop through sendMessage is not something we can rely on, so this is allowed to fail and
   * the badge falls back to its in-page panel when it does.
   */
  "panel:open": async (m, sender) => {
    const tabId = sender?.tab?.id ?? m.tabId;
    if (!tabId) throw new Error("no tab to open beside");
    if (m.address) await ledger.setFocus(tabId, m.address);
    if (!chrome.sidePanel?.open) throw new Error("this browser has no side panel");
    await chrome.sidePanel.open({ tabId });
    return { opened: true };
  },

  /**
   * What the trades say about a token, as corroboration rather than as a price readout.
   *
   * Deliberately not folded into `scan`: a verdict must not become slower, or start failing,
   * because a market API is having a bad day. It is asked for separately, when a reader wants
   * it, and a null answer costs nothing.
   */
  "market:get": (m) => readMarket(m.address, { chain: m.chain }),

  /**
   * Price history, from a different source than the tape.
   *
   * GeckoTerminal's free tier is tight - enumerating their network list while building this
   * earned a 429 - so this is only ever called when a reader asks for a chart, and the pool
   * address found by the market read is passed through to save the lookup call.
   */
  "candles:get": (m) => readCandles(m.address, { chain: m.chain, pool: m.pool, key: m.key }),

  /**
   * Check somebody else's accusation.
   *
   * Takes whatever was pasted - the format's own copy output, a chat quote, a fenced block -
   * finds the claims in it, and runs the evidence here against the public endpoints the claim
   * names. Nothing about the reporter is consulted, which is the entire point: the reader
   * ends up believing the chain, or not, rather than believing a stranger.
   *
   * Invalid claims come back with their reasons rather than being dropped. "This is not
   * checkable and here is why" is a useful answer about an accusation someone is spreading.
   */
  "claim:check": async (m) => {
    const claims = parseClaims(m.text);
    if (!claims.length) return { claims: [] };
    const out = [];
    for (const claim of claims.slice(0, 5)) {
      const valid = validateClaim(claim);
      out.push({
        claim,
        valid: valid.ok,
        errors: valid.errors || [],
        result: valid.ok ? await runClaim(claim) : null,
      });
    }
    return { claims: out };
  },

  /** The account strip under a post was clicked: open the panel on that account's record. */
  "panel:caller": async (m, sender) => {
    const tabId = sender?.tab?.id ?? m.tabId;
    if (!tabId) throw new Error("no tab to open beside");
    await ledger.setCallerFocus(tabId, m.handle);
    if (!chrome.sidePanel?.open) throw new Error("this browser has no side panel");
    await chrome.sidePanel.open({ tabId });
    return { opened: true };
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = HANDLERS[msg?.type];
  if (!handler) return false;
  Promise.resolve(handler(msg, sender))
    .then((data) => sendResponse({ ok: true, data }))
    .catch((err) => sendResponse({ ok: false, error: String(err?.message || err) }));
  return true; // keep the channel open for the async reply
});

// A closed tab's reading session is over. Session storage would clear on browser exit
// anyway, but a long-lived window should not accumulate ledgers for tabs that are gone.
chrome.tabs.onRemoved.addListener((tabId) => ledger.drop(tabId));

// The toolbar icon opens the side panel directly. There is no popup any more: two surfaces
// meant every feature had to be decided twice, and the sidebar is the one with room.
const useSidePanel = () =>
  chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {});

// Keep the registry warm so no badge ever waits on it.
chrome.runtime.onInstalled.addListener(() => {
  useSidePanel();
  chrome.alarms.create("registry", { periodInMinutes: 55 });
  chrome.alarms.create("upkeep", { periodInMinutes: 180 });
  getRegistry({ force: true }).catch(() => {});
  getBlocklist({ force: true }).catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  useSidePanel();
  getRegistry().catch(() => {});
  getBlocklist().catch(() => {});
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "registry") {
    getRegistry({ force: true }).catch(() => {});
    getBlocklist({ force: true }).catch(() => {});
  }
  if (a.name === "upkeep") {
    pruneMemory().catch(() => {});
    graph.pruneGraph().catch(() => {});
  }
});
